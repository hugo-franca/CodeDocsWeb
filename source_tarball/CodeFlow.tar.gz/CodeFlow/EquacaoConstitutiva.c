#include "EquacaoConstitutiva.h"

///FORMULACAO CARTESIANA

void EquacoesConstitutivas(double **LambdaVelho, double **MuVelho, double **NuVelho, double **LambdaNovo,  double **MuNovo, double **NuNovo, double **LambdaAux, double **NuAux,
                            double **TxxVelho, double **TxyVelho, double **TyyVelho, double **TxtVelho, double **TytVelho, double **TttVelho,
                            double **TxxNovo, double **TxyNovo, double **TyyNovo, double **TxtNovo, double **TytNovo, double **TttNovo,
                            double **PsiVelho_xx, double **PsiVelho_xy, double **PsiVelho_yy, double **PsiNovo_xx, double **PsiNovo_xy, double **PsiNovo_yy, double **O_11, double **O_12, double **O_21, double **O_22, double **Lambda1, double **Lambda2,
                            double **UVelho, double **VVelho, double **WVelho, double **UNovo, double **VNovo, double **WNovo,
                            double **TermoDominanteXX, double **TermoDominanteXY, double **TermoDominanteYY,
                            int n, MALHA M)
{
    int i, j, linha;
    double xi, tol, velU, velV, modV;

    xi = (1.0 - M.beta)/(/*M.Re**/M.We);
    tol = M.tolNSF;


    ///Calculando as variaveis auxiliares pro termo convectivo do NSF
    if( M.formulacaoVisco==VISCO_NSF || M.formulacaoVisco==VISCO_HIBRIDO ) {
        for( linha=0; linha<M.qtdIncognitasP; linha++ ) {
            i = M.indicesP[linha].i;
            j = M.indicesP[linha].j;

            velU = 0.5*( UNovo[i+1][j] + UNovo[i][j] );
            velV = 0.5*( VNovo[i][j+1] + VNovo[i][j] );
            //velU = 0.5*( UVelho[i+1][j] + UVelho[i][j] );
            //velV = 0.5*( VVelho[i][j+1] + VVelho[i][j] );
            modV = velU*velU + velV*velV;

            LambdaAux[i][j] = LambdaVelho[i][j]/( modV + tol );
            NuAux[i][j] = modV*NuVelho[i][j];
        }
    }

    if( M.formulacaoVisco==VISCO_LOG ) {
        for( linha=0; linha<M.qtdIncognitasP; linha++ ) {
            i = M.indicesP[linha].i;
            j = M.indicesP[linha].j;

            double A[4][4], O[4][4], auto_valores[4], aux1[4], aux2[4];
            int nrot;
            A[1][1] = 1.0 + TxxVelho[i][j]/xi;
            A[1][2] = TxyVelho[i][j]/xi;
            A[2][1] = TxyVelho[i][j]/xi;
            A[2][2] = 1.0 + TyyVelho[i][j]/xi;

            CalculaAutovalores_Jacobi(A, 2, auto_valores, aux1, aux2, O, &nrot);

            PsiVelho_xx[i][j] = O[1][1]*O[1][1]*log(auto_valores[1]) + O[1][2]*O[1][2]*log(auto_valores[2]);

            PsiVelho_xy[i][j] = O[1][1]*O[2][1]*log(auto_valores[1]) + O[2][2]*O[1][2]*log(auto_valores[2]);

            PsiVelho_yy[i][j] = O[2][1]*O[2][1]*log(auto_valores[1]) + O[2][2]*O[2][2]*log(auto_valores[2]);


            O_11[i][j] = O[1][1];
            O_12[i][j] = O[1][2];
            O_21[i][j] = O[2][1];
            O_22[i][j] = O[2][2];

            Lambda1[i][j] = auto_valores[1];
            Lambda2[i][j] = auto_valores[2];
        }
    }

    ///Agora aplicando as equacoes constitutivas em cada celula
    for( linha=0; linha<M.qtdIncognitasP; linha++ ) {
        i = M.indicesP[linha].i;
        j = M.indicesP[linha].j;

        velU = 0.5*( UNovo[i+1][j] + UNovo[i][j] );
        velV = 0.5*( VNovo[i][j+1] + VNovo[i][j] );
        //velU = 0.5*( UVelho[i+1][j] + UVelho[i][j] );
        //velV = 0.5*( VVelho[i][j+1] + VVelho[i][j] );
        modV = velU*velU + velV*velV;

        if( M.formulacaoVisco==VISCO_CART )
            EquacoesConstitutivasCartesiano(i, j, TxxVelho, TxyVelho, TyyVelho, TxtVelho, TytVelho, TttVelho,
                                            TxxNovo, TxyNovo, TyyNovo, TxtNovo, TytNovo, TttNovo,
                                            UNovo, VNovo, WNovo, n, M);
        else if( M.formulacaoVisco==VISCO_NSF ) {
            EquacoesConstitutivasNSF(i, j, LambdaVelho, MuVelho, NuVelho, LambdaNovo, MuNovo, NuNovo, LambdaAux, NuAux,
                                        UVelho, VVelho, UNovo, VNovo, n, M);

            //CONVERSAO
            tol = M.tolNSFconversao;
            TxxNovo[i][j] = xi*( -1.0 + ( ( LambdaNovo[i][j]*velU*velU - MuNovo[i][j]*2.0*velU*velV + NuNovo[i][j]*velV*velV )/( modV + tol ) ) );
            TxyNovo[i][j] = (xi/(modV + tol))*( LambdaNovo[i][j]*velU*velV + MuNovo[i][j]*(velU*velU - velV*velV) - NuNovo[i][j]*velU*velV );
            TyyNovo[i][j] = xi*( -1.0 + ( ( LambdaNovo[i][j]*velV*velV + MuNovo[i][j]*2.0*velU*velV + NuNovo[i][j]*velU*velU )/( modV + tol ) ) );
        }
        else if( M.formulacaoVisco==VISCO_HIBRIDO ) {

            if( ProximoDaParede_Hibrido(i, j, M) ) {

                //PrintDebug("(%d %d) ", i, j);

                EquacoesConstitutivasCartesiano(i, j, TxxVelho, TxyVelho, TyyVelho, TxtVelho, TytVelho, TttVelho,
                                            TxxNovo, TxyNovo, TyyNovo, TxtNovo, TytNovo, TttNovo,
                                            UNovo, VNovo, WNovo, n, M);
                //EquacoesConstitutivasCartesiano(i, j, TxxVelho, TxyVelho, TyyVelho, TxxNovo, TxyNovo, TyyNovo, UVelho, VVelho, n, M);

                //Conversao
                tol = M.tolNSFconversao;
                LambdaNovo[i][j] = 1.0 + ( (TxxNovo[i][j]*velU*velU + TxyNovo[i][j]*2.0*velU*velV + TyyNovo[i][j]*velV*velV)/(xi*(modV+tol)) );
                MuNovo[i][j] = (-TxxNovo[i][j]*velU*velV + TxyNovo[i][j]*(velU*velU - velV*velV) + TyyNovo[i][j]*velU*velV)/(xi*(modV+tol));
                NuNovo[i][j] = 1.0 + ( (TxxNovo[i][j]*velV*velV - TxyNovo[i][j]*2.0*velU*velV + TyyNovo[i][j]*velU*velU)/(xi*(modV+tol)) );
            }
            else {

                EquacoesConstitutivasNSF(i, j, LambdaVelho, MuVelho, NuVelho, LambdaNovo, MuNovo, NuNovo, LambdaAux, NuAux,
                                        UVelho, VVelho, UNovo, VNovo, n, M);

                //Conversao
                tol = M.tolNSFconversao;
                TxxNovo[i][j] = xi*( -1.0 + ( ( LambdaNovo[i][j]*velU*velU - MuNovo[i][j]*2.0*velU*velV + NuNovo[i][j]*velV*velV )/( modV + tol ) ) );
                TxyNovo[i][j] = (xi/(modV + tol))*( LambdaNovo[i][j]*velU*velV + MuNovo[i][j]*(velU*velU - velV*velV) - NuNovo[i][j]*velU*velV );
                TyyNovo[i][j] = xi*( -1.0 + ( ( LambdaNovo[i][j]*velV*velV + MuNovo[i][j]*2.0*velU*velV + NuNovo[i][j]*velU*velU )/( modV + tol ) ) );
            }

        }
        else if( M.formulacaoVisco==VISCO_LOG ) {
            EquacoesConstitutivasLogConformation(i, j, PsiVelho_xx, PsiVelho_xy, PsiVelho_yy, PsiNovo_xx, PsiNovo_xy, PsiNovo_yy,
                                                 O_11, O_12, O_21, O_22, Lambda1, Lambda2,
                                                 UNovo, VNovo, n, M);

            double psi[4][4], O[4][4], auto_valores[4], aux1[4], aux2[4];
            int nrot;
            psi[1][1] = PsiNovo_xx[i][j];
            psi[1][2] = PsiNovo_xy[i][j];
            psi[2][1] = PsiNovo_xy[i][j];
            psi[2][2] = PsiNovo_yy[i][j];

            CalculaAutovalores_Jacobi(psi, 2, auto_valores, aux1, aux2, O, &nrot);

            double A11, A12, A22;
            A11 = O[1][1]*O[1][1]*exp(auto_valores[1]) + O[1][2]*O[1][2]*exp(auto_valores[2]);
            A12 = O[1][1]*O[2][1]*exp(auto_valores[1]) + O[2][2]*O[1][2]*exp(auto_valores[2]);
            A22 = O[2][1]*O[2][1]*exp(auto_valores[1]) + O[2][2]*O[2][2]*exp(auto_valores[2]);

            TxxNovo[i][j] = xi*(A11 - 1.0);
            TxyNovo[i][j] = xi*(A12);
            TyyNovo[i][j] = xi*(A22 - 1.0);
        }
        else DeuProblema("EquacoesConstitutivas: Opcao viscoelastico invalida.\n\n");

        CalculaTermoDominanteEqsConstituvas(i, j, TxxVelho, TxyVelho, TyyVelho, TxtVelho, TytVelho, TttVelho,
                                            TxxNovo, TxyNovo, TyyNovo, TxtNovo, TytNovo, TttNovo,
                                            UNovo, VNovo, WNovo, TermoDominanteXX, TermoDominanteXY, TermoDominanteYY,
                                            n, M);


    }

    //DeuProblema("ACABOU\n");

}

void EquacoesConstitutivasCartesiano(int i, int j,
                                     double **Txx_Velho, double **Txy_Velho, double **Tyy_Velho, double **Txt_Velho, double **Tyt_Velho, double **Ttt_Velho,
                                     double **Txx_Novo, double **Txy_Novo, double **Tyy_Novo, double **Txt_Novo, double **Tyt_Novo, double **Ttt_Novo,
                                     double **U, double **V, double **W, int n, MALHA M)
{
    double dudx, dudy, dvdx, dvdy, dwdx, dwdy;
    double convecTxx, convecTxy, convecTyy, convecTxt, convecTyt, convecTtt;
    double xi;
    double parteWi, parteCilindrico;

    // Ignora se for beta==1
    if( M.beta==1.0 )
        return;

    xi = (1.0 - M.beta)/(/*M.Re**/M.We);

    dudx = DerivadaDUDX(U, i, j, M);
    dudy = DerivadaDUDY(U, i, j, (n+1)*M.dt, M);
    dvdx = DerivadaDVDX(V, i, j, M);
    dvdy = DerivadaDVDY(V, i, j, M);
    dwdx = (M.tipoCoord==AXI_CILINDRICO) ? DerivadaDWDX(W, i, j, M) : 0.0;
    dwdy = (M.tipoCoord==AXI_CILINDRICO) ? DerivadaDWDY(W, i, j, M) : 0.0;
    convecTxx = Conv_Tensor(Txx_Velho, U, V, i, j, "txx", M);
    convecTxy = Conv_Tensor(Txy_Velho, U, V, i, j, "txy", M);
    convecTyy = Conv_Tensor(Tyy_Velho, U, V, i, j, "tyy", M);
    convecTxt = (M.tipoCoord==AXI_CILINDRICO) ? Conv_Tensor(Txt_Velho, U, V, i, j, "txt", M) : 0.0;
    convecTyt = (M.tipoCoord==AXI_CILINDRICO) ? Conv_Tensor(Tyt_Velho, U, V, i, j, "tyt", M) : 0.0;
    convecTtt = (M.tipoCoord==AXI_CILINDRICO) ? Conv_Tensor(Ttt_Velho, U, V, i, j, "ttt", M) : 0.0;

    parteWi = - (1.0/M.We)*( Txx_Velho[i][j] )
             - ( (M.epsilon/(1.0-M.beta))*(Txx_Velho[i][j] + Tyy_Velho[i][j])*Txx_Velho[i][j] )
            //- ( (M.alpha/(1.0-M.beta))*(Txx_Velho[i][j]*Txx_Velho[i][j] + Txy_Velho[i][j]*Txy_Velho[i][j] + Txt_Velho[i][j]*Txt_Velho[i][j]) )
            ;
    parteCilindrico = ( M.tipoCoord == AXI_CILINDRICO ) ? - 2.0*(W[i][j]/M.r[i])*Txt_Velho[i][j] : 0.0;
    Txx_Novo[i][j] = Txx_Velho[i][j] + M.dt*( - convecTxx + parteCilindrico + 2.0*dudx*Txx_Velho[i][j] + 2.0*dudy*Txy_Velho[i][j] + 2.0*xi*dudx + parteWi );

    parteWi = - (1.0/M.We)*( Txy_Velho[i][j] )
            - ( (M.epsilon/(1.0-M.beta))*(Txx_Velho[i][j] + Tyy_Velho[i][j])*Txy_Velho[i][j] )
            //- ( (M.alpha/(1.0-M.beta))*( Txx_Velho[i][j]*Txy_Velho[i][j] + Tyy_Velho[i][j]*Txy_Velho[i][j] + Txt_Velho[i][j]*Tyt_Velho[i][j] ) )
            ;
    parteCilindrico = ( M.tipoCoord == AXI_CILINDRICO ) ? (dudx + dvdy)*Txy_Velho[i][j] - (W[i][j]/M.r[i])*Tyt_Velho[i][j] : 0.0;
    Txy_Novo[i][j] = Txy_Velho[i][j] + M.dt*( - convecTxy + parteCilindrico + dvdx*Txx_Velho[i][j] + dudy*Tyy_Velho[i][j] + xi*(dudy + dvdx) + parteWi );

    parteWi = - (1.0/M.We)*( Tyy_Velho[i][j] )
            - ( (M.epsilon/(1.0-M.beta))*(Txx_Velho[i][j] + Tyy_Velho[i][j])*Tyy_Velho[i][j] )
            //- ( (M.alpha/(1.0-M.beta))*( Txy_Velho[i][j]*Txy_Velho[i][j] + Tyt_Velho[i][j]*Tyt_Velho[i][j] + Tyy_Velho[i][j]*Tyy_Velho[i][j] ) )
            ;
    Tyy_Novo[i][j] = Tyy_Velho[i][j] + M.dt*( - convecTyy + 2.0*dvdx*Txy_Velho[i][j] + 2.0*dvdy*Tyy_Velho[i][j] + 2.0*xi*dvdy + parteWi );

    if( M.tipoCoord == AXI_CILINDRICO ) {
        parteWi = - (1.0/M.We)*( Txt_Velho[i][j] );
//                - ( (M.alpha/(1.0-M.beta))*( Txx_Velho[i][j]*Txt_Velho[i][j] + Txt_Velho[i][j]*Ttt_Velho[i][j] + Txy_Velho[i][j]*Tyt_Velho[i][j] ) );
        parteCilindrico = (U[i][j]/M.r[i])*Txt_Velho[i][j] - (W[i][j]/M.r[i])*Ttt_Velho[i][j];
        Txt_Novo[i][j] = Txt_Velho[i][j] + M.dt*( - convecTxt + parteCilindrico + dudx*Txt_Velho[i][j] + dudy*Tyt_Velho[i][j] + dwdx*Txx_Velho[i][j] + dwdy*Txy_Velho[i][j] + xi*(dwdx - (W[i][j]/M.r[i])) + parteWi );

        parteWi = - (1.0/M.We)*( Tyt_Velho[i][j] );
//                - ( (M.alpha/(1.0-M.beta))*( Txt_Velho[i][j]*Tyt_Velho[i][j] + Tyt_Velho[i][j]*Ttt_Velho[i][j] + Tyt_Velho[i][j]*Tyy_Velho[i][j] ) );
        parteCilindrico = (U[i][j]/M.r[i])*Tyt_Velho[i][j];
        Tyt_Novo[i][j] = Tyt_Velho[i][j] + M.dt*( - convecTyt + parteCilindrico + dwdx*Txy_Velho[i][j] + dwdy*Tyy_Velho[i][j] + dvdx*Txt_Velho[i][j] + dvdy*Tyt_Velho[i][j] + xi*dwdy + parteWi );

        parteWi = - (1.0/M.We)*( Ttt_Velho[i][j] );
//                - ( (M.alpha/(1.0-M.beta))*( Txt_Velho[i][j]*Txt_Velho[i][j] + Ttt_Velho[i][j]*Ttt_Velho[i][j] + Tyt_Velho[i][j]*Tyt_Velho[i][j] ) );;
        parteCilindrico = 2.0*(U[i][j]/M.r[i])*Ttt_Velho[i][j];
        Ttt_Novo[i][j] = Ttt_Velho[i][j] + M.dt*( - convecTtt + parteCilindrico + 2.0*dwdx*Txt_Velho[i][j] + 2.0*dwdy*Tyt_Velho[i][j] + 2.0*xi*(U[i][j]/M.r[i]) + parteWi );
    }






    return;
}

/// FORMULACAO NATURAL-STRESS
void EquacoesConstitutivasNSF(int i, int j, double **LambdaVelho, double **MuVelho, double **NuVelho, double **LambdaNovo,  double **MuNovo, double **NuNovo, double **LambdaAux, double **NuAux,
                              double **UVelho, double **VVelho, double **UNovo, double **VNovo, int n, MALHA M)
{
    double dudx, dudy, dvdx, dudt, dvdt, velV, velU, modV, convecLambda, convecMu, convecNu;
    double parteTempo, parteConvec, parteDivW, parteWi;
    double tol;

    // Ignora se for beta==1, pois eh newtoniano
    if( M.beta==1.0 )
        return;

    tol = M.tolNSF;

    dudx = DerivadaDUDX(UNovo, i, j, M);
    dudy = DerivadaDUDY(UNovo, i, j, (n+1)*M.dt, M);
    dvdx = DerivadaDVDX(VNovo, i, j, M);
    dudt = DerivadaDUDT(UVelho, UNovo, i, j, M);
    dvdt = DerivadaDVDT(VVelho, VNovo, i, j, M);
    velU = 0.5*( UNovo[i+1][j] + UNovo[i][j] );
    velV = 0.5*( VNovo[i][j+1] + VNovo[i][j] );
    modV = velU*velU + velV*velV;


    convecLambda = Conv_Tensor(LambdaAux, UNovo, VNovo, i, j, "lambdaAux", M);
    convecMu = Conv_Tensor(MuVelho, UNovo, VNovo, i, j, "mu", M);
    convecNu = Conv_Tensor(NuAux, UNovo, VNovo, i, j, "nuAux", M);


    parteTempo = (-2.0*MuVelho[i][j]/(modV + tol))*(velV*dudt - velU*dvdt);
    parteConvec = - modV*convecLambda;
    parteDivW = -2.0*MuVelho[i][j]*( (velV*velV - velU*velU)*( dvdx + dudy ) + 4.0*velU*velV*dudx )/( modV + tol );
    parteWi = ( -(LambdaVelho[i][j] - 1.0)/M.We ) //Parte Oldroyd-B
            + ( (M.epsilon/M.We)*(LambdaVelho[i][j] + NuVelho[i][j] - 2.0)*(1.0 - LambdaVelho[i][j]) ) //Parte PTT
            - ( (M.alpha/M.We)*( ((LambdaVelho[i][j] - 1.0)*(LambdaVelho[i][j] - 1.0)) + (MuVelho[i][j]*MuVelho[i][j]) ) ); //Parte Geisekus
    LambdaNovo[i][j] = LambdaVelho[i][j] + M.dt*( parteTempo  + parteConvec + parteDivW + parteWi );


    parteTempo = -( (LambdaVelho[i][j] - NuVelho[i][j])/(modV + tol))*(velU*dvdt - velV*dudt);
    parteConvec = - convecMu;
    parteDivW = -NuVelho[i][j]*( (velV*velV - velU*velU)*( dvdx + dudy ) + 4.0*velU*velV*dudx )/( modV + tol );
    parteWi = - (MuVelho[i][j]/M.We)
            + ( (M.epsilon/M.We)*(LambdaVelho[i][j] + NuVelho[i][j] - 2.0)*(-MuVelho[i][j]) ) //Parte PTT
            + ( (M.alpha/M.We)*(LambdaVelho[i][j] + NuVelho[i][j] - 2.0)*(-MuVelho[i][j]) ); //Parte Geisekus
    MuNovo[i][j] = MuVelho[i][j] + M.dt*( parteTempo  + parteConvec + parteDivW + parteWi );

    parteTempo = (-2.0*MuVelho[i][j]/(modV + tol))*(velU*dvdt - velV*dudt);
    parteConvec = - convecNu/( modV + tol );
    parteDivW = 0.0;
    parteWi = (-(NuVelho[i][j] - 1.0)/M.We)
            + ( (M.epsilon/M.We)*(LambdaVelho[i][j] + NuVelho[i][j] - 2.0)*(1.0-NuVelho[i][j]) ) //Parte PTT
            - ( (M.alpha/M.We)*( ((NuVelho[i][j] - 1.0)*(NuVelho[i][j] - 1.0)) + (MuVelho[i][j]*MuVelho[i][j]) ) ); //Parte Geisekus
    NuNovo[i][j] = NuVelho[i][j] + M.dt*( parteTempo  + parteConvec + parteDivW + parteWi );

    return;
}

void EquacoesConstitutivasLogConformation(int i, int j, double **PsiVelho_xx, double **PsiVelho_xy, double **PsiVelho_yy, double **PsiNovo_xx, double **PsiNovo_xy, double **PsiNovo_yy,
                                          double **O_11, double **O_12, double **O_21, double **O_22, double **Lambda1, double **Lambda2,
                                          double **U, double **V, int n, MALHA M)
{
    double o11, o12, o21, o22;
    double M11, M12, M21, M22;
    double B11, B12, B22;
    double S12, S_Tio; // Matriz sigma
    double dudx, dudy, dvdx, dvdy;
    double convecPsiXX, convecPsiXY, convecPsiYY;

    dudx = DerivadaDUDX(U, i, j, M);
    dudy = DerivadaDUDY(U, i, j, (n+1)*M.dt, M);
    dvdx = DerivadaDVDX(V, i, j, M);
    dvdy = DerivadaDVDY(V, i, j, M);
    convecPsiXX = Conv_Tensor(PsiVelho_xx, U, V, i, j, "PsiXX", M);
    convecPsiXY = Conv_Tensor(PsiVelho_xy, U, V, i, j, "PsiXY", M);
    convecPsiYY = Conv_Tensor(PsiVelho_yy, U, V, i, j, "PsiYY", M);


    o11 = O_11[i][j];
    o12 = O_12[i][j];
    o21 = O_21[i][j];
    o22 = O_22[i][j];

    M11 = o11*o11*dudx + o11*o21*dvdx + o11*o21*dudy + o21*o21*dvdy;
    M12 = o11*o12*dudx + o12*o21*dvdx + o11*o22*dudy + o21*o22*dvdy;
    M21 = o11*o12*dudx + o11*o22*dvdx + o12*o21*dudy + o21*o22*dvdy;
    M22 = o12*o12*dudx + o12*o22*dvdx + o12*o22*dudy + o22*o22*dvdy;

    B11 = o11*o11*M11 + o12*o12*M22;
    B12 = o11*o21*M11 + o22*o12*M22;
    B22 = o21*o21*M11 + o22*o22*M22;

    S_Tio = (M12*Lambda2[i][j] + M21*Lambda1[i][j])/(Lambda2[i][j] - Lambda1[i][j] + 1e-20);
    S12 = -o12*o21*S_Tio + o11*o22*S_Tio;

//    PrintDebug("%d %d: aa %lf %lf %lf aabbb\n", i, j, Lambda1[i][j], Lambda2[i][j], S12);
//    getchar();

    double parteSigma, parteWi;

    parteSigma = 2.0*( PsiVelho_xy[i][j]*S12 + B11 );
    //parteWi = (1.0/M.We)*( (o11*o11/Lambda1[i][j]) + (o12*o12/Lambda2[i][j]) )*( 1.0 - o11*o11*Lambda1[i][j] - o12*o12*Lambda2[i][j] );
    parteWi = (1.0/M.We)*( (o11*o11/Lambda1[i][j]) + (o12*o12/Lambda2[i][j]) - 1.0 );
    PsiNovo_xx[i][j] = PsiVelho_xx[i][j] + M.dt*( - convecPsiXX + parteSigma + parteWi );

    parteSigma = S12*( PsiVelho_yy[i][j] - PsiVelho_xx[i][j] ) + 2.0*B12;
    //parteWi = (1.0/M.We)*( (o11*o21/Lambda1[i][j]) + (o12*o22/Lambda2[i][j]) )*( - o11*o21*Lambda1[i][j] - o12*o22*Lambda2[i][j] );
    parteWi = (1.0/M.We)*( (o11*o21/Lambda1[i][j]) + (o12*o22/Lambda2[i][j]) );
    PsiNovo_xy[i][j] = PsiVelho_xy[i][j] + M.dt*( - convecPsiXY + parteSigma + parteWi );


    parteSigma = 2.0*( - PsiVelho_xy[i][j]*S12 + B22 );
    //parteWi = (1.0/M.We)*( (o21*o21/Lambda1[i][j]) + (o22*o22/Lambda2[i][j]) )*( 1.0 - o21*o21*Lambda1[i][j] - o22*o22*Lambda2[i][j] );
    parteWi = (1.0/M.We)*( (o21*o21/Lambda1[i][j]) + (o22*o22/Lambda2[i][j]) - 1.0 );
    PsiNovo_yy[i][j] = PsiVelho_yy[i][j] + M.dt*( - convecPsiYY + parteSigma + parteWi );



    return;
}

double DerivadaDUDX(double **U, int i, int j, MALHA M)
{
    return (U[i+1][j] - U[i][j])/M.dx[i];
}

double DerivadaDUDY(double **U, int i, int j, double t, MALHA M)
{
    static double uCimaDir = 0.0, uCimaEsq = 0.0, uBaixoDir = 0.0, uBaixoEsq = 0.0, uCentroEsq = 0.0, uCentroDir = 0.0;
    static double h1, h2;

    uCentroEsq = U[i][j];
    uCentroDir = U[i+1][j];

    ///Encontrando o uCimaEsq
    if( CIMA_U(i, j) ) {
        if( M.pontosV[i][j+1].tipoBoundary == NOSLIP )
            uCimaEsq = - U[i][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i, j, M.x[i], t, U );
        else if( M.pontosV[i][j+1].tipoBoundary == SLIP )
            uCimaEsq = - U[i][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i, j, M.x[i], t, U );
        else if( M.pontosV[i][j+1].tipoBoundary == INFLOW )
            uCimaEsq = - U[i][j];
        else if( M.pontosV[i][j+1].tipoBoundary == NEUMANN )
            uCimaEsq = U[i][j];
        else if( M.pontosV[i][j+1].tipoBoundary == SIMETRIA )
            uCimaEsq = U[i][j];
        else DeuProblema("Problema DerivadaDUDY Cima esquerda %d %d\n", i, j);
    }
    else
        uCimaEsq = U[i][j+1];

    ///Encontrando uCimaDir
    if( CIMA_U(i+1, j) ) {
        if( M.pontosV[i][j+1].tipoBoundary == NOSLIP )
            uCimaDir = - U[i+1][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i+1, j, M.x[i+1], t, U );
        else  if( M.pontosV[i][j+1].tipoBoundary == SLIP )
            uCimaDir = - U[i+1][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i+1, j, M.x[i+1], t, U );
        else if( M.pontosV[i][j+1].tipoBoundary == INFLOW )
            uCimaDir = - U[i+1][j];
        else if( M.pontosV[i][j+1].tipoBoundary == NEUMANN )
            uCimaDir = U[i+1][j];
        else if( M.pontosV[i][j+1].tipoBoundary == SIMETRIA )
            uCimaDir = U[i+1][j];
        else DeuProblema("Problema DerivadaDUDY Cima direita %d %d\n", i, j);
    }
    else
        uCimaDir = U[i+1][j+1];

    ///Encontrando uBaixoEsq
    if( BAIXO_U(i, j) ) {
        if( M.pontosV[i][j].tipoBoundary == NOSLIP )
            uBaixoEsq = - U[i][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i, j, M.x[i], t, U );
        else  if( M.pontosV[i][j].tipoBoundary == SLIP )
            uBaixoEsq = - U[i][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i, j, M.x[i], t, U );
        else if( M.pontosV[i][j].tipoBoundary == INFLOW )
            uBaixoEsq = - U[i][j];
        else if( M.pontosV[i][j].tipoBoundary == NEUMANN )
            uBaixoEsq = U[i][j];
        else if( M.pontosV[i][j].tipoBoundary == SIMETRIA )
            uBaixoEsq = U[i][j];
        else DeuProblema("Problema DerivadaDUDY baixo esquerda %d %d\n", i, j);
    }
    else
        uBaixoEsq = U[i][j-1];

    if( BAIXO_U(i+1, j) ) {
        if( M.pontosV[i][j].tipoBoundary == NOSLIP )
            uBaixoDir = - U[i+1][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i+1, j, M.x[i+1], t, U );
        else if( M.pontosV[i][j].tipoBoundary == SLIP )
            uBaixoDir = - U[i+1][j] + 2.0*FuncaoValorNoSlipHorizontal( M, i+1, j, M.x[i+1], t, U );
        else if( M.pontosV[i][j].tipoBoundary == INFLOW )
            uBaixoDir = - U[i+1][j];
        else if( M.pontosV[i][j].tipoBoundary == NEUMANN )
            uBaixoDir = U[i+1][j];
        else if( M.pontosV[i][j].tipoBoundary == SIMETRIA )
            uBaixoDir = U[i+1][j];
        else DeuProblema("Problema DerivadaDUDY baixo direita %d %d\n", i, j);
    }
    else
        uBaixoDir = U[i+1][j-1];


    h1 = (j==0) ? M.dy[j] : 0.5*( M.dy[j-1] + M.dy[j] );
    h2 = (j==M.Ny-1) ? M.dy[j] : 0.5*( M.dy[j] + M.dy[j+1] );

    return ( (-h2/(h1*(h1+h2)))*0.5*( uBaixoEsq + uBaixoDir ) ) +
                 ( ((h2-h1)/(h1*h2))*0.5*( uCentroEsq + uCentroDir ) ) +
                 ( (h1/(h2*(h1+h2)))*0.5*( uCimaEsq + uCimaDir ) );
}

double DerivadaDVDX(double **V, int i, int j, MALHA M)
{
    static double vDirCima = 0.0, vEsqCima = 0.0, vDirBaixo = 0.0, vEsqBaixo = 0.0, vCentroCima = 0.0, vCentroBaixo = 0.0;
    static double h1 = 0.0, h2 = 0.0;

    vCentroBaixo = V[i][j];
    vCentroCima = V[i][j+1];


    if( ESQUERDA_V(i, j) ) {
        if( M.pontosU[i][j].tipoBoundary == NOSLIP )
            vEsqBaixo = - V[i][j] + 2.0*FuncaoValorNoSlipVertical( M, i, j, M.y[j], 0.0, V );
        else if( M.pontosU[i][j].tipoBoundary == SLIP )
            vEsqBaixo = - V[i][j] + 2.0*FuncaoValorNoSlipVertical( M, i, j, M.y[j], 0.0, V );
        else if( M.pontosU[i][j].tipoBoundary == INFLOW )
            vEsqBaixo = - V[i][j];
        else if( M.pontosU[i][j].tipoBoundary == EIXO_AXISSIMETRIA )
            vEsqBaixo = V[i][j];
        else DeuProblema("Problema Esquerda DerivadaDVDX: %d %d\n", i, j);
    }
    else
        vEsqBaixo = V[i-1][j];

    if( ESQUERDA_V(i, j+1) ) {
        if( M.pontosU[i][j].tipoBoundary == NOSLIP )
            vEsqCima = - V[i][j+1] + 2.0*FuncaoValorNoSlipVertical( M, i, j+1, M.y[j], 0.0, V );
        else if( M.pontosU[i][j].tipoBoundary == SLIP )
            vEsqCima = - V[i][j+1] + 2.0*FuncaoValorNoSlipVertical( M, i, j+1, M.y[j], 0.0, V );
        else if( M.pontosU[i][j].tipoBoundary == INFLOW )
            vEsqCima = - V[i][j+1];
        else if( M.pontosU[i][j].tipoBoundary == EIXO_AXISSIMETRIA )
            vEsqCima = V[i][j+1];
        else DeuProblema("Problema Esquerda DerivadaDVDX: %d %d\n", i, j);
    }
    else
        vEsqCima = V[i-1][j+1];

    ///Encontrando vDirBaixo
    if( DIREITA_V(i, j) ) {
        if( M.pontosU[i+1][j].tipoBoundary==NEUMANN )
            vDirBaixo = V[i][j];
        else if( M.pontosU[i+1][j].tipoBoundary==NOSLIP )
            vDirBaixo = - V[i][j] + 2.0*FuncaoValorNoSlipVertical( M, i, j, M.y[j], 0.0, V );
        else if( M.pontosU[i+1][j].tipoBoundary==SLIP )
            vDirBaixo = - V[i][j] + 2.0*FuncaoValorNoSlipVertical( M, i, j, M.y[j], 0.0, V );
        else if( M.pontosU[i+1][j].tipoBoundary==INFLOW )
            vDirBaixo = - V[i][j];
        else DeuProblema("Problema Direita DerivadaDVDX: %d %d\n", i, j);
    }
    else
        vDirBaixo = V[i+1][j];

    if( DIREITA_V(i, j+1) ) {
        if( M.pontosU[i+1][j].tipoBoundary==NEUMANN )
            vDirCima = V[i][j+1];
        else if( M.pontosU[i+1][j].tipoBoundary==NOSLIP )
            vDirCima = - V[i][j+1] + 2.0*FuncaoValorNoSlipVertical( M, i, j+1, M.y[j], 0.0, V );
        else if( M.pontosU[i+1][j].tipoBoundary==SLIP )
            vDirCima = - V[i][j+1] + 2.0*FuncaoValorNoSlipVertical( M, i, j+1, M.y[j], 0.0, V );
        else if( M.pontosU[i+1][j].tipoBoundary==INFLOW )
            vDirCima = - V[i][j+1];
        else DeuProblema("Problema Direita DerivadaDVDX: %d %d\n", i, j);
    }
    else
        vDirCima = V[i+1][j+1];

    h1 = (i==0) ? M.dx[i] : 0.5*( M.dx[i-1] + M.dx[i] );
    h2 = (i==M.Nx-1) ? M.dx[i] : 0.5*( M.dx[i] + M.dx[i+1] );

    return ( (-h2/(h1*(h1+h2)))*0.5*( vEsqBaixo + vEsqCima ) ) +
                 ( ((h2-h1)/(h1*h2))*0.5*( vCentroBaixo + vCentroCima ) ) +
                 ( (h1/(h2*(h1+h2)))*0.5*( vDirBaixo + vDirCima ) );
}

double DerivadaDVDY(double **V, int i, int j, MALHA M)
{
    return (V[i][j+1] - V[i][j])/M.dy[j];
}

double DerivadaDWDX(double **W, int i, int j, MALHA M)
{
    double wEsq = 0.0, wDir = 0.0, wCentro = 0.0;
    double valorDirichlet;

    wCentro = W[i][j];

    //Encontrando o W(i-1, j)
    if( i!=0 && M.pontosW[i-1][j].tipo==FULL ) {
        wEsq = W[i-1][j];
    }
    else {
        if( M.pontosU[i][j].movimento==MOVIMENTO_THETA )
            valorDirichlet = M.pontosU[i][j].valorDirichlet;
        else
            valorDirichlet = 0.0;



        if( M.pontosU[i][j].tipoBoundary == NOSLIP )
            wEsq = - W[i][j] + 2.0*valorDirichlet;
        else if( M.pontosU[i][j].tipoBoundary == INFLOW )
            wEsq = - W[i][j];
        else if( M.pontosU[i][j].tipoBoundary == EIXO_AXISSIMETRIA )
            wEsq = W[i][j];
        else
            printf("\n\n Problema Esquerda - DWDX\n\n");
    }

    //Encontarndo o W(i+1, j)
    if( i!=M.Nx-1 && M.pontosW[i+1][j].tipo==FULL ) {
        wDir = W[i+1][j];
    }
    else {

        if( M.pontosU[i+1][j].movimento==MOVIMENTO_THETA )
            valorDirichlet = M.pontosU[i+1][j].valorDirichlet;
        else
            valorDirichlet = 0.0;

        if( M.pontosU[i+1][j].tipoBoundary == NOSLIP )
            wDir = - W[i][j] + 2.0*valorDirichlet;
        else if( M.pontosU[i+1][j].tipoBoundary == INFLOW )
            wDir = - W[i][j];
        else
            printf("\n\n Problema Direita - DWDX\n\n");
    }

    double h1 = (i==0) ? M.dx[i] : 0.5*( M.dx[i-1] + M.dx[i] );
    double h2 = (i==M.Nx-1) ? M.dx[i] : 0.5*( M.dx[i] + M.dx[i+1] );

    return ( (-h2/(h1*(h1+h2)))*wEsq ) +
                 ( ((h2-h1)/(h1*h2))*wCentro ) +
                 ( (h1/(h2*(h1+h2)))*wDir );
}

double DerivadaDWDY(double **W, int i, int j, MALHA M)
{
    double wBaixo = 0.0, wCima = 0.0, wCentro = 0.0;

    wCentro = W[i][j];

    //Encontrando o W(i, j-1)
    if( j!=0 && M.pontosW[i][j-1].tipo==FULL ) {
        wBaixo = W[i][j-1];
    }
    else {
        if( M.pontosV[i][j].tipoBoundary == NOSLIP )
            wBaixo = - W[i][j];
        else if( M.pontosV[i][j].tipoBoundary == INFLOW )
            wBaixo = - W[i][j];
        else if( M.pontosV[i][j].tipoBoundary == NEUMANN )
            wBaixo = W[i][j];
        else
            printf("problema Baixo - Convectivo Theta");
    }

    //Encontrando o W(i, j+1)
    if( j!=M.Ny-1 && M.pontosW[i][j+1].tipo==FULL ) {
        wCima = W[i][j+1];
    }
    else {
        if( M.pontosV[i][j+1].tipoBoundary == NOSLIP )
            wCima = - W[i][j];
        else if( M.pontosV[i][j+1].tipoBoundary == INFLOW )
            wCima = - W[i][j];
        else if( M.pontosV[i][j+1].tipoBoundary == NEUMANN )
            wCima = W[i][j];
        else
            printf("problema Cima - Convectivo Theta");
    }

    double h1 = (j==0) ? M.dy[j] : 0.5*( M.dy[j-1] + M.dy[j] );
    double h2 = (j==M.Ny-1) ? M.dy[j] : 0.5*( M.dy[j] + M.dy[j+1] );

    return ( (-h2/(h1*(h1+h2)))*wBaixo ) +
                 ( ((h2-h1)/(h1*h2))*wCentro ) +
                 ( (h1/(h2*(h1+h2)))*wCima );
}

double DerivadaDUDT(double **UVelho, double **UNovo, int i, int j, MALHA M)
{
    return 0.5*(UNovo[i+1][j] + UNovo[i][j] - UVelho[i+1][j] - UVelho[i][j])/M.dt;
}

double DerivadaDVDT(double **VVelho, double **VNovo, int i, int j, MALHA M)
{
    return 0.5*(VNovo[i][j+1] + VNovo[i][j] - VVelho[i][j+1] - VVelho[i][j])/M.dt;
}

int ProximoDaParede_Hibrido(int i, int j, MALHA M)
{
    int grauHibrido;
    //int grauDiagonal;

    grauHibrido = M.grauHibrido;
    //grauDiagonal = 1;

    ///BLOCOS CSF - teste cassio
//    int alturaBloco = 50;
//    if( i<70 ) {
//        if( (j<alturaBloco) || ((259-j)<alturaBloco) )
//            return 1;
//    }



//    int iQuina1, iQuina2, jQuina1, jQuina2;
//
//    int raioQuina = 40;
//
//    iQuina1 = 69;
//    jQuina1 = 90;
//    iQuina2 = 69;
//    jQuina2 = 169;
//
//    if( (abs(i-iQuina1)<=raioQuina) && (abs(j-jQuina1)<=raioQuina) )
//        return 0;
//    if( (abs(i-iQuina2)<=raioQuina) && (abs(j-jQuina2)<=raioQuina) )
//        return 0;

//
//    if( ((260-j)<=grauHibrido) && (i>=50) ) {
//        return 1;
//    }
//    if( (j<grauHibrido) && (i>=50) ) {
//        return 1;
//    }
//
//    if( (j>=210) && ((70-i)<=grauHibrido) ) {
//        return 1;
//    }
//    if( (j<50) && ((70-i)<=grauHibrido) ) {
//        return 1;
//    }

    //Casos obvios, pois estao nos extremos do dominio geral
    if( (i<grauHibrido) || ((M.Nx-i)<=grauHibrido) || (j<grauHibrido) || ((M.Ny-j)<=grauHibrido) )
        return 1;

    //Casos nao-obvios, pois estao proximos a uma parede no meio do dominio (tipo o problema da contracao)
    for( ; grauHibrido>0; grauHibrido-- ) {
        if( M.pontosP[i-grauHibrido][j].tipo==EMPTY )
            return 1;
        if( M.pontosP[i+grauHibrido][j].tipo==EMPTY )
            return 1;
        if( M.pontosP[i][j-grauHibrido].tipo==EMPTY )
            return 1;
        if( M.pontosP[i][j+grauHibrido].tipo==EMPTY )
            return 1;

//        //Aplicando tambem na quina
//        if( M.pontosP[i-grauDiagonal][j-grauDiagonal].tipo==EMPTY )
//            return 1;
//        if( M.pontosP[i-grauDiagonal][j+grauDiagonal].tipo==EMPTY )
//            return 1;
//        if( M.pontosP[i+grauDiagonal][j-grauDiagonal].tipo==EMPTY )
//            return 1;
//        if( M.pontosP[i+grauDiagonal][j+grauDiagonal].tipo==EMPTY )
//            return 1;
    }

    return 0;
}


double CalculaDetMinA(MALHA M, double **Txx, double **Txy, double **Tyy)
{
    int i, j;
    double menorDet = 1e+10, det;
    double xi = (1.0 - M.beta)/(/*M.Re**/M.We);
    static double A[3][3];

    for( i=0; i<M.Nx; i++ ) {
        for( j=0; j<M.Ny; j++ ) {
            A[1][1] = 1.0 + Txx[i][j]/xi;
            A[1][2] = Txy[i][j]/xi;
            A[2][1] = Txy[i][j]/xi;
            A[2][2] = 1.0 + Tyy[i][j]/xi;

            det = A[1][1]*A[2][2] - A[1][2]*A[2][1];

            if( menorDet>det )
                menorDet = det;
        }
    }

    return menorDet;
}

void CalculaResiduosEqsConstitutivas(MALHA *M, double **UVelho, double **UNovo , double **VVelho, double **VNovo,
                          double **TxxVelho, double **TxxNovo, double **TxyVelho, double **TxyNovo, double **TyyVelho, double **TyyNovo,
                          double **LambdaVelho, double **LambdaNovo, double **MuVelho, double **MuNovo, double **NuVelho, double **NuNovo,
                          double **LambdaAux, double **NuAux,
                          double **PsiVelho_xx, double **PsiNovo_xx, double **PsiVelho_xy, double **PsiNovo_xy, double **PsiVelho_yy, double **PsiNovo_yy,
                          double **ResTxx, double **ResTxy, double **ResTyy,
                          double **ResLambda, double **ResMu, double **ResNu,
                          double **ResPsiXX, double **ResPsiXY, double **ResPsiYY)
{
    int i, j;
    double dudx, dudy, dvdx, dvdy, dudt, dvdt;
    double convecTxx, convecTxy, convecTyy, convecLambda, convecMu, convecNu, convecPsiXX, convecPsiXY, convecPsiYY;
    double parteTempo, parteConv, parteWi, parte2, parteDivW, parteDelT;
    double velU, velV, modV;

    //double tol = M->tolNSF;
    double tol = 0.0;

    if( M->formulacaoVisco==VISCO_NSF || M->formulacaoVisco==VISCO_HIBRIDO ) {
        int linha;
        for( linha=0; linha<M->qtdIncognitasP; linha++ ) {
            i = M->indicesP[linha].i;
            j = M->indicesP[linha].j;

            velU = 0.5*( UNovo[i+1][j] + UNovo[i][j] );
            velV = 0.5*( VNovo[i][j+1] + VNovo[i][j] );
            modV = velU*velU + velV*velV;

            LambdaAux[i][j] = LambdaNovo[i][j]/( modV + tol );
            NuAux[i][j] = modV*NuNovo[i][j];
//
//            LambdaAux[i][j] = LambdaVelho[i][j]/( modV + tol);
//            NuAux[i][j] = modV*NuVelho[i][j];
        }
    }

    for( i=0; i<M->Nx; i++) {
        for( j=0; j<M->Ny; j++ ) {

            //Vou calcular apenas em pontos FULL
            if( M->pontosP[i][j].tipo!=FULL )
                continue;

            dudx = DerivadaDUDX(UNovo, i, j, *M);
            dudy = DerivadaDUDY(UNovo, i, j, 0.0, *M);
            dvdx = DerivadaDVDX(VNovo, i, j, *M);
            dvdy = DerivadaDVDY(VNovo, i, j, *M);
            dudt = DerivadaDUDT(UVelho, UNovo, i, j, *M);
            dvdt = DerivadaDVDT(VVelho, VNovo, i, j, *M);
            convecTxx = Conv_Tensor(TxxNovo, UNovo, VNovo, i, j, "txx", *M);
            convecTxy = Conv_Tensor(TxyNovo, UNovo, VNovo, i, j, "txy", *M);
            convecTyy = Conv_Tensor(TyyNovo, UNovo, VNovo, i, j, "tyy", *M);

            parteTempo = (TxxNovo[i][j] - TxxVelho[i][j])/(M->dt);
            parteConv = convecTxx;
            parte2 = - 2.0*( dudx*TxxNovo[i][j] + dudy*TxyNovo[i][j] );
            parteWi = - (2.0/M->We)*(1.0 - M->beta)*dudx;
            ResTxx[i][j] = ((1.0/M->We)*TxxNovo[i][j]) + parteTempo + parteConv + parte2 + parteWi;

            parteTempo = (TxyNovo[i][j] - TxyVelho[i][j])/(M->dt);
            parteConv = convecTxy;
            parte2 = - ( dvdx*TxxNovo[i][j] + dudy*TyyNovo[i][j] );
            parteWi = - (1.0/M->We)*(1.0 - M->beta)*(dudy + dvdx);
            ResTxy[i][j] = ((1.0/M->We)*TxyNovo[i][j]) + parteTempo + parteConv + parte2 + parteWi;

            parteTempo = (TyyNovo[i][j] - TyyVelho[i][j])/(M->dt);
            parteConv = convecTyy;
            parte2 = - 2.0*( dvdx*TxyNovo[i][j] + dvdy*TyyNovo[i][j] );
            parteWi = - (2.0/M->We)*(1.0 - M->beta)*dvdy;
            ResTyy[i][j] = ((1.0/M->We)*TyyNovo[i][j]) + parteTempo + parteConv + parte2 + parteWi;




            velU = 0.5*( UNovo[i+1][j] + UNovo[i][j] );
            velV = 0.5*( VNovo[i][j+1] + VNovo[i][j] );
            modV = velU*velU + velV*velV;
            convecLambda = Conv_Tensor(LambdaAux, UNovo, VNovo, i, j, "lambdaAux", *M);
            convecMu = Conv_Tensor(MuNovo, UNovo, VNovo, i, j, "mu", *M);
            convecNu = Conv_Tensor(NuAux, UNovo, VNovo, i, j, "nuAux", *M);

            parteDelT = (LambdaNovo[i][j] - LambdaVelho[i][j])/M->dt;
            parteTempo = (2.0*MuNovo[i][j]/(modV + tol))*(velV*dudt - velU*dvdt);
            parteConv = modV*convecLambda;
            parteDivW = 2.0*MuNovo[i][j]*( (velV*velV - velU*velU)*( dvdx + dudy ) + 4.0*velU*velV*dudx )/( modV + tol );
            parteWi = (LambdaNovo[i][j] - 1.0)/M->We;
            ResLambda[i][j] = parteDelT + parteTempo + parteConv + parteDivW + parteWi;

            parteDelT = (MuNovo[i][j] - MuVelho[i][j])/M->dt;
            parteTempo = ((LambdaNovo[i][j] - NuNovo[i][j])/(modV + tol ))*(velU*dvdt - velV*dudt);
            parteConv = convecMu;
            parteDivW = NuNovo[i][j]*( (velV*velV - velU*velU)*( dvdx + dudy ) + 4.0*velU*velV*dudx )/( modV + tol );
            parteWi = (MuNovo[i][j]/M->We); //Parte Geisekus
            ResMu[i][j] = parteDelT + parteTempo + parteConv + parteDivW + parteWi;

            parteDelT = (NuNovo[i][j] - NuVelho[i][j])/M->dt;
            parteTempo = (2.0*MuNovo[i][j]/(modV + tol))*(velU*dvdt - velV*dudt);
            parteConv = convecNu/( modV + tol );
            parteDivW = 0.0;
            parteWi = ((NuNovo[i][j] - 1.0)/M->We);
            ResNu[i][j] = parteDelT + parteTempo + parteConv + parteDivW + parteWi;






            convecPsiXX = Conv_Tensor(PsiNovo_xx, UNovo, VNovo, i, j, "PsiXX", *M);
            convecPsiXY = Conv_Tensor(PsiNovo_xy, UNovo, VNovo, i, j, "PsiXY", *M);
            convecPsiYY = Conv_Tensor(PsiNovo_yy, UNovo, VNovo, i, j, "PsiYY", *M);

            double xi = (1.0 - M->beta)/(/*M.Re**/M->We);
            double A[4][4], O[4][4], auto_valores[4], aux1[4], aux2[4];
            int nrot;
            A[1][1] = 1.0 + TxxNovo[i][j]/xi;
            A[1][2] = TxyNovo[i][j]/xi;
            A[2][1] = TxyNovo[i][j]/xi;
            A[2][2] = 1.0 + TyyNovo[i][j]/xi;

            CalculaAutovalores_Jacobi(A, 2, auto_valores, aux1, aux2, O, &nrot);

            double o11 = O[1][1];
            double o12 = O[1][2];
            double o21 = O[2][1];
            double o22 = O[2][2];

            double M11 = o11*o11*dudx + o11*o21*dvdx + o11*o21*dudy + o21*o21*dvdy;
            double M12 = o11*o12*dudx + o12*o21*dvdx + o11*o22*dudy + o21*o22*dvdy;
            double M21 = o11*o12*dudx + o11*o22*dvdx + o12*o21*dudy + o21*o22*dvdy;
            double M22 = o12*o12*dudx + o12*o22*dvdx + o12*o22*dudy + o22*o22*dvdy;

            double B11 = o11*o11*M11 + o12*o12*M22;
            double B12 = o11*o21*M11 + o22*o12*M22;
            double B22 = o21*o21*M11 + o22*o22*M22;

            double S_Tio = (M12*auto_valores[2] + M21*auto_valores[1])/(auto_valores[2] - auto_valores[1] + 1e-20);
            double S12 = -o12*o21*S_Tio + o11*o22*S_Tio;

            double parteSigma, parteWi, parteTempo;

            parteTempo = (PsiNovo_xx[i][j] - PsiVelho_xx[i][j])/M->dt;
            parteSigma = 2.0*( PsiNovo_xy[i][j]*S12 + B11 );
            parteWi = (1.0/M->We)*( (o11*o11/auto_valores[1]) + (o12*o12/auto_valores[2]) - 1.0 );
            ResPsiXX[i][j] = parteTempo + convecPsiXX - parteSigma - parteWi;

            parteTempo = (PsiNovo_xy[i][j] - PsiVelho_xy[i][j])/M->dt;
            parteSigma = S12*( PsiNovo_yy[i][j] - PsiNovo_xx[i][j] ) + 2.0*B12;
            parteWi = (1.0/M->We)*( (o11*o21/auto_valores[1]) + (o12*o22/auto_valores[2]) );
            ResPsiXY[i][j] = parteTempo + convecPsiXY - parteSigma - parteWi;

            parteTempo = (PsiNovo_yy[i][j] - PsiVelho_yy[i][j])/M->dt;
            parteSigma = 2.0*( - PsiNovo_xy[i][j]*S12 + B22 );
            parteWi = (1.0/M->We)*( (o21*o21/auto_valores[1]) + (o22*o22/auto_valores[2]) - 1.0 );
            ResPsiYY[i][j] = parteTempo + convecPsiYY - parteSigma - parteWi;

            ///Apenas testando pra ser se da zero usando valores em n
//            velU = 0.5*( UNovo[i+1][j] + UNovo[i][j] );
//            velV = 0.5*( VNovo[i][j+1] + VNovo[i][j] );
//            modV = velU*velU + velV*velV;
//            convecLambda = Conv_Tensor(LambdaAux, UNovo, VNovo, i, j, "lambdaAux", *M);
//            convecMu = Conv_Tensor(MuVelho, UNovo, VNovo, i, j, "mu", *M);
//            convecNu = Conv_Tensor(NuAux, UNovo, VNovo, i, j, "nuAux", *M);
//
//            parteDelT = (LambdaNovo[i][j] - LambdaVelho[i][j])/M->dt;
//            parteTempo = (2.0*MuVelho[i][j]/(modV + tol))*(velV*dudt - velU*dvdt);
//            parteConv = modV*convecLambda;
//            parteDivW = 2.0*MuVelho[i][j]*( (velV*velV - velU*velU)*( dvdx + dudy ) + 4.0*velU*velV*dudx )/( modV + tol );
//            parteWi = (LambdaVelho[i][j] - 1.0)/M->We;
//            ResLambda[i][j] = parteDelT + parteTempo + parteConv + parteDivW + parteWi;
//
//            parteDelT = (MuNovo[i][j] - MuVelho[i][j])/M->dt;
//            parteTempo = ((LambdaVelho[i][j] - NuVelho[i][j])/(modV + tol))*(velU*dvdt - velV*dudt);
//            parteConv = convecMu;
//            parteDivW = NuVelho[i][j]*( (velV*velV - velU*velU)*( dvdx + dudy ) + 4.0*velU*velV*dudx )/( modV + tol );
//            parteWi = (MuVelho[i][j]/M->We); //Parte Geisekus
//            ResMu[i][j] = parteDelT + parteTempo + parteConv + parteDivW + parteWi;
//
//            parteDelT = (NuNovo[i][j] - NuVelho[i][j])/M->dt;
//            parteTempo = (2.0*MuVelho[i][j]/(modV + tol ))*(velU*dvdt - velV*dudt);
//            parteConv = convecNu/( modV + tol );
//            parteDivW = 0.0;
//            parteWi = ((NuVelho[i][j] - 1.0)/M->We);
//            ResNu[i][j] = parteDelT + parteTempo + parteConv + parteDivW + parteWi;
        }
    }
}

void CalculaTermoDominanteEqsConstituvas(int i, int j,
                                         double **Txx_Velho, double **Txy_Velho, double **Tyy_Velho, double **Txt_Velho, double **Tyt_Velho, double **Ttt_Velho,
                                         double **Txx_Novo, double **Txy_Novo, double **Tyy_Novo, double **Txt_Novo, double **Tyt_Novo, double **Ttt_Novo,
                                         double **U, double **V, double **W,
                                         double **TermoDominanteXX, double **TermoDominanteXY, double **TermoDominanteYY,
                                         int n, MALHA M)
{
    double dudx, dudy, dvdx, dvdy;//, dwdx, dwdy;
    double convecTxx, convecTxy, convecTyy;//, convecTxt, convecTyt, convecTtt;
    double xi;

    // Ignora se for beta==1
    if( M.beta==1.0 )
        return;

    xi = (1.0 - M.beta)/(/*M.Re**/M.We);

    dudx = DerivadaDUDX(U, i, j, M);
    dudy = DerivadaDUDY(U, i, j, (n+1)*M.dt, M);
    dvdx = DerivadaDVDX(V, i, j, M);
    dvdy = DerivadaDVDY(V, i, j, M);
//    dwdx = (M.tipoCoord==AXI_CILINDRICO) ? DerivadaDWDX(W, i, j, M) : 0.0;
//    dwdy = (M.tipoCoord==AXI_CILINDRICO) ? DerivadaDWDY(W, i, j, M) : 0.0;
    convecTxx = Conv_Tensor(Txx_Velho, U, V, i, j, "txx", M);
    convecTxy = Conv_Tensor(Txy_Velho, U, V, i, j, "txy", M);
    convecTyy = Conv_Tensor(Tyy_Velho, U, V, i, j, "tyy", M);
//    convecTxt = (M.tipoCoord==AXI_CILINDRICO) ? Conv_Tensor(Txt_Velho, U, V, i, j, "txt", M) : 0.0;
//    convecTyt = (M.tipoCoord==AXI_CILINDRICO) ? Conv_Tensor(Tyt_Velho, U, V, i, j, "tyt", M) : 0.0;
//    convecTtt = (M.tipoCoord==AXI_CILINDRICO) ? Conv_Tensor(Ttt_Velho, U, V, i, j, "ttt", M) : 0.0;

    /// FABIANO: Verificando qual o termo dominante
    /// === Verificando o termo dominante pra imprimir no VTK
    double termo1, termo2, termo3;
    // Primeiramente componente xx
    termo1 = fabs(Txx_Novo[i][j])/M.We;
    termo2 = fabs( ((Txx_Novo[i][j] - Txx_Velho[i][j])/M.dt) + convecTxx - 2.0*dudx*Txx_Novo[i][j] - 2.0*dudy*Txy_Novo[i][j] );
    termo3 = fabs( 2.0*xi*dudx );
    if( (termo1>termo2) && (termo1>termo3) )
        TermoDominanteXX[i][j] = 1.0;
    else if( termo2>termo3 )
        TermoDominanteXX[i][j] = 2.0;
    else
        TermoDominanteXX[i][j] = 3.0;

    // Agora componente xy
    termo1 = fabs(Txy_Novo[i][j])/M.We;
    termo2 = fabs( ((Txy_Novo[i][j] - Txy_Velho[i][j])/M.dt) + convecTxy - dvdx*Txx_Novo[i][j] - dudy*Tyy_Novo[i][j] );
    termo3 = fabs( xi*(dudy + dvdx) );
    if( (termo1>termo2) && (termo1>termo3) )
        TermoDominanteXY[i][j] = 1.0;
    else if( termo2>termo3 )
        TermoDominanteXY[i][j] = 2.0;
    else
        TermoDominanteXY[i][j] = 3.0;

    // Agora componente YY
    termo1 = fabs(Tyy_Novo[i][j])/M.We;
    termo2 = fabs( ((Tyy_Novo[i][j] - Tyy_Velho[i][j])/M.dt) + convecTyy - 2.0*dvdx*Txy_Novo[i][j] - 2.0*dvdy*Tyy_Novo[i][j] );
    termo3 = fabs( 2.0*xi*dvdy );
    if( (termo1>termo2) && (termo1>termo3) )
        TermoDominanteXY[i][j] = 1.0;
    else if( termo2>termo3 )
        TermoDominanteXY[i][j] = 2.0;
    else
        TermoDominanteXY[i][j] = 3.0;

    return;
}


