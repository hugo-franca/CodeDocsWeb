#ifndef EQUACAO_CONSTITUTIVA
#define EQUACAO_CONSTITUTIVA

#include <stdlib.h>
#include <stdio.h>
#include "Malha.h"
#include "Derivadas.h"

///FORMULACAO CARTESIANA

void EquacoesConstitutivas(double **LambdaVelho, double **MuVelho, double **NuVelho, double **LambdaNovo,  double **MuNovo, double **NuNovo, double **LambdaAux, double **NuAux,
                            double **TxxVelho, double **TxyVelho, double **TyyVelho, double **TxtVelho, double **TytVelho, double **TttVelho,
                            double **TxxNovo, double **TxyNovo, double **TyyNovo, double **TxtNovo, double **TytNovo, double **TttNovo,
                            double **PsiVelho_xx, double **PsiVelho_xy, double **PsiVelho_yy, double **PsiNovo_xx, double **PsiNovo_xy, double **PsiNovo_yy, double **O_11, double **O_12, double **O_21, double **O_22, double **Lambda1, double **Lambda2,
                            double **UVelho, double **VVelho, double **WVelho, double **UNovo, double **VNovo, double **WNovo,
                            double **TermoDominanteXX, double **TermoDominanteXY, double **TermoDominanteYY,
                            int n, MALHA M);

void EquacoesConstitutivasCartesiano(int i, int j,
                                     double **Txx_Velho, double **Txy_Velho, double **Tyy_Velho, double **Txt_Velho, double **Tyt_Velho, double **Ttt_Velho,
                                     double **Txx_Novo, double **Txy_Novo, double **Tyy_Novo, double **Txt_Novo, double **Tyt_Novo, double **Ttt_Novo,
                                     double **U, double **V, double **W, int n, MALHA M);

void EquacoesConstitutivasNSF(int i, int j, double **LambdaVelho, double **MuVelho, double **NuVelho, double **LambdaNovo,  double **MuNovo, double **NuNovo, double **LambdaAux, double **NuAux,
                              double **UVelho, double **VVelho, double **UNovo, double **VNovo, int n, MALHA M);

void EquacoesConstitutivasLogConformation(int i, int j, double **PsiVelho_xx, double **PsiVelho_xy, double **PsiVelho_yy, double **PsiNovo_xx, double **PsiNovo_xy, double **PsiNovo_yy,
                                          double **O_11, double **O_12, double **O_21, double **O_22, double **Lambda1, double **Lambda2,
                                          double **U, double **V, int n, MALHA M);

double DerivadaDUDX(double **U, int i, int j, MALHA M);

double DerivadaDUDY(double **U, int i, int j, double t, MALHA M);

double DerivadaDVDX(double **V, int i, int j, MALHA M);

double DerivadaDVDY(double **V, int i, int j, MALHA M);

double DerivadaDWDX(double **W, int i, int j, MALHA M);

double DerivadaDWDY(double **W, int i, int j, MALHA M);

double DerivadaDUDT(double **UVelho, double **UNovo, int i, int j, MALHA M);

double DerivadaDVDT(double **VVelho, double **VNovo, int i, int j, MALHA M);

int ProximoDaParede_Hibrido(int i, int j, MALHA M);



double CalculaDetMinA(MALHA M, double **Txx, double **Txy, double **Tyy);

void CalculaResiduosEqsConstitutivas(MALHA *M, double **UVelho, double **UNovo , double **VVelho, double **VNovo,
                          double **TxxVelho, double **TxxNovo, double **TxyVelho, double **TxyNovo, double **TyyVelho, double **TyyNovo,
                          double **LambdaVelho, double **LambdaNovo, double **MuVelho, double **MuNovo, double **NuVelho, double **NuNovo,
                          double **LambdaAux, double **NuAux,
                          double **PsiVelho_XX, double **PsiNovo_XX, double **PsiVelho_XY, double **PsiNovo_XY, double **PsiVelho_YY, double **PsiNovo_YY,
                          double **ResTxx, double **ResTxy, double **ResTyy,
                          double **ResLambda, double **ResMu, double **ResNu,
                          double **ResPsiXX, double **ResPsiXY, double **ResPsiYY);

void CalculaTermoDominanteEqsConstituvas(int i, int j,
                                         double **Txx_Velho, double **Txy_Velho, double **Tyy_Velho, double **Txt_Velho, double **Tyt_Velho, double **Ttt_Velho,
                                         double **Txx_Novo, double **Txy_Novo, double **Tyy_Novo, double **Txt_Novo, double **Tyt_Novo, double **Ttt_Novo,
                                         double **U, double **V, double **W,
                                         double **TermoDominanteXX, double **TermoDominanteXY, double **TermoDominanteYY,
                                         int n, MALHA M);

#endif // EQUACAO_CONSTITUTIVA
