#include "MachineLearning.h"

double TestarRede(REDE_NEURAL Rede, double *DadosTeste)
{
    int i_camada;
    int i_input, i_output;

    // Normalizando os dados de entrada
    for( i_input=0; i_input<Rede.camadas[0].qtd_input; i_input++ )
        DadosTeste[i_input] = (DadosTeste[i_input] - Rede.media[i_input])/Rede.desvio[i_input];

    for( i_camada=0; i_camada<Rede.qtdCamadas; i_camada++ ) {
        double **pesos = Rede.camadas[i_camada].pesos;
        double *biases = Rede.camadas[i_camada].biases;
        double *valores_out = Rede.camadas[i_camada].valores_out;
        double *valores_in = (i_camada == 0) ? DadosTeste : Rede.camadas[i_camada-1].valores_out;
        double (*ativacao)(double) = (i_camada==Rede.qtdCamadas-1) ? &Linear : &Relu;

        // Calculando o valor de cada output desta camada
        for( i_output=0; i_output<Rede.camadas[i_camada].qtd_output; i_output++ ) {

            valores_out[i_output] = biases[i_output];
            for( i_input=0; i_input<Rede.camadas[i_camada].qtd_input; i_input++ )
                valores_out[i_output] += pesos[i_input][i_output]*valores_in[i_input];
            valores_out[i_output] = ativacao( valores_out[i_output] );

        }
    }

    return Rede.camadas[Rede.qtdCamadas-1].valores_out[0];
}

REDE_NEURAL LerRedeDoArquivo(const char *NomeArquivo)
{
    FILE *arq;
    REDE_NEURAL rede;
    int qtdInput, qtdOutput;
    int i, j, i_camada, temp;
    double valor = 0.0;


    arq = fopen(NomeArquivo, "rt");

    temp = fscanf(arq, "qtd_input: %d \n", &qtdInput);
    rede.media = (double *)malloc( qtdInput*sizeof(double) );
    rede.desvio = (double *)malloc( qtdInput*sizeof(double) );

    // Lendo os dados pra normalizacao
    temp = fscanf(arq, "stats_norm\n");
    temp = fscanf(arq, "mean: ");
    for( i=0; i<qtdInput; i++ )
        temp = fscanf(arq, "%lf ", &(rede.media[i]));
    temp = fscanf(arq, "\n");
    temp = fscanf(arq, "std: ");
    for( i=0; i<qtdInput; i++ )
        temp = fscanf(arq, "%lf ", &(rede.desvio[i]));

    //Lendo as camadas
    temp = fscanf(arq, "qtd_camadas: %d\n", &(rede.qtdCamadas));
    rede.camadas = (CAMADA_REDE *) malloc( (rede.qtdCamadas)*sizeof(CAMADA_REDE) );

    for( i_camada=0; i_camada<rede.qtdCamadas; i_camada++ ) {
        temp = fscanf(arq, "camada %d\n", &temp);
        temp = fscanf(arq, "shape: (%d, %d)\n", &qtdInput, &qtdOutput);

        rede.camadas[i_camada].pesos = (double **) AlocaMatriz(qtdInput, qtdOutput, sizeof(double), &valor);
        rede.camadas[i_camada].biases = (double *) malloc( qtdOutput*sizeof(double) );
        rede.camadas[i_camada].valores_out = (double *) malloc( qtdOutput*sizeof(double) );
        rede.camadas[i_camada].qtd_input = qtdInput;
        rede.camadas[i_camada].qtd_output = qtdOutput;

        temp = fscanf(arq, "weights\n");
        for( i=0; i<qtdInput; i++ ) {
            for( j=0; j<qtdOutput; j++ )
                temp = fscanf( arq, "%lf ", &(rede.camadas[i_camada].pesos[i][j]) );
            temp = fscanf(arq, "\n");
        }

        temp = fscanf(arq, "biases\n");
        for( j=0; j<qtdOutput; j++ )
            temp = fscanf( arq, "%lf ", &(rede.camadas[i_camada].biases[j]) );
        temp = fscanf(arq, "\n");
    }


    fclose(arq);


    return rede;
}

double Relu(double Valor)
{
    return (Valor > 0.0) ? Valor : 0.0;
}

double Linear(double Valor)
{
    return Valor;
}

