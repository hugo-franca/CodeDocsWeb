#ifndef MACHINE_LEARNING_H
#define MACHINE_LEARNING_H

#include <stdio.h>
#include <stdlib.h>
#include "FuncoesAuxiliares.h"

typedef struct CamadaRede {
    int qtd_input, qtd_output;
    double **pesos;
    double *biases;
    double *valores_out;
} CAMADA_REDE;

typedef struct RedeNeural {
    int qtdCamadas;
    double *media, *desvio; //Media e desvio padrao usado pra normalizar o input
    CAMADA_REDE *camadas;
} REDE_NEURAL;

REDE_NEURAL LerRedeDoArquivo(const char *NomeArquivo);

double TestarRede(REDE_NEURAL Rede, double *DadosTeste);

double Relu(double Valor);

double Linear(double Valor);

#endif

