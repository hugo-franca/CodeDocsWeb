#ifndef VISUALIZACAO_H
#define VISUALIZACAO_H

#include "Malha.h"
#include "InterfaceFrontTracking.h"

void ImprimeArquivosUVPGnuplot(double **U, double **V, double **W, double **P, MALHA Malha, int n);

void ImprimeArquivoVTK(double **U, double **V, double **W, double **P,
                       double **Txx, double **Txy, double **Tyy, double **Txt, double **Tyt, double **Ttt,
                       double **TermoDominanteXX, double **TermoDominanteXY, double **TermoDominanteYY,
                       double **Lambda, double **Mu, double **Nu, MALHA Malha, int n);

void ImprimeInterfaceVTK(MALHA Malha, int n);

void ImprimeCorte(double **U, double **V, double **W, int Indice, const char *Direcao, const char *Variavel, const char *NomeArquivo, MALHA M);

void PlotU(MALHA Malha, int n);

void PlotV(MALHA Malha, int n);

void PlotP(MALHA Malha, int n);

void PlotW(MALHA Malha, int n);



///Superficie livre
void ImprimePontosCurva(CURVA Curva, FILE *Arquivo);

void ImprimeCurvasEPontos(INTERFACE Interface);

void PlotInterfaceGnuplot(MALHA Malha, char DesenhaMalha, char DesenhaNormais, int n);


#endif // VISUALIZACAO_H
