static char help[] = "Simulador Navier-Stokes. Projeto de mestrado, Hugo Franca\n\n";

#include <petscksp.h>

#include "FuncoesAuxiliares.h"
#include "Malha.h"
#include "InterfaceFrontTracking.h"
#include "MetodoProjecao.h"
#include "Visualizacao.h"

char nomePastaArquivos[300] = "";

const int velocidadeNewtoniana = 0;

double *hVelho = NULL;

#undef __FUNCT__
#define __FUNCT__ "main"
int main(int argc,char **args)
{
    PetscErrorCode ierr;
    SOLVER_PROJECAO solver;
    MALHA malha;
    LISTA_CELULAS_SURFACE listaCelulasSurf;
    double residuo = 0.0;
    int n;
    int rank;


    PetscInitialize(&argc, &args, (char*)0, help);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);


    listaCelulasSurf.prim = NULL;
    listaCelulasSurf.ult = NULL;


    /// ==== Pegando o nome do arquivo na linha de comando e lendo o arquivo
    char arquivoSim[200];
    PetscBool flagArquivo;
    ierr = PetscOptionsGetString(NULL, NULL, "-arquivo", arquivoSim, 200, &flagArquivo); CHKERRQ(ierr);
    if( !flagArquivo )
        DeuProblema("\n\nERRO: Forneca o nome do arquivo de entrada.\n\n");
    malha = LerModeloDoArquivo(arquivoSim);


    PrintDebug("Inicializando estruturas \n");
    strcpy(nomePastaArquivos, malha.nomeArquivo);

    /// ==== Aloca memoria para todas matrizes de solucoes
    ierr = InicializaEstruturasProjecao(&solver, malha); CHKERRQ(ierr);

    n = -1;
//    CarregarEstadoBinario(&malha, solver.UVelho, solver.VVelho, solver.PVelho, solver.TxxVelho, solver.TxyVelho, solver.TyyVelho, solver.lambdaVelho, solver.muVelho, solver.nuVelho, &listaCelulasSurf, &n);
    //CarregarEstado(&malha, solver.UVelho, solver.VVelho, solver.PVelho, solver.TxxVelho, solver.TxyVelho, solver.TyyVelho, &listaCelulasSurf, &n);

    /// ==== Imprimeces a solucao inicial e a malha computacional inicial nos arquivos vtk
//    ImprimeArquivoVTK(solver.UVelho, solver.VVelho, solver.WVelho, solver.PVelho,
//                              solver.TxxVelho, solver.TxyVelho, solver.TyyVelho, solver.TxtVelho, solver.TytVelho, solver.TttVelho,
//                              solver.lambdaVelho, solver.muVelho, solver.nuVelho, malha, n+1);;
    ImprimeInterfaceVTK(malha, n+1);
    DesenhaMalhaVTK(malha, 0);

    double t = 0.0;

    PrintDebug("Inicializando passos temporais \n");
    for( n++; n<malha.Nt; n++ ) {

        malha.passoTemporal = n;

        clock_t start, end;
        double cpu_time_used;
        start = clock();

        ierr = ExecutaPassoTemporalProjecao(&solver, &malha, n, rank, &listaCelulasSurf, &residuo); CHKERRQ(ierr);

        end = clock();
        cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

        if( n%malha.intervaloPrint==0 && rank==0 )
            PrintDebug("Passo %d finalizado. residuo=%.15e CPU_TIME: %g\n\n", n+1, residuo, cpu_time_used);

        if( isnan(residuo) || isinf(residuo) )
            DeuProblema("\n\n Valor estranho no residuo: %lf\n\n", residuo);


        /// ==== Imprimindo o arquivo VTK que contem as propriedades no dominio (U, V, P, T, etc...)
        if( (malha.intervaloVTK_prop) && ((n+1)%(malha.intervaloVTK_prop)==0) && rank==0 ) {
            ImprimeArquivoVTK(solver.UVelho, solver.VVelho, solver.WVelho, solver.PVelho,
                              solver.TxxVelho, solver.TxyVelho, solver.TyyVelho, solver.TxtVelho, solver.TytVelho, solver.TttVelho,
                              solver.lambdaVelho, solver.muVelho, solver.nuVelho,
                              solver.termoDominanteXX, solver.termoDominanteXY, solver.termoDominanteYY,
                              malha, n+1);
            DesenhaMalhaVTK(malha, 0);
        }


        /// ==== Imprimindo o arquivo VTK que contem a superficie livre (se houver)
        if( (malha.intervaloVTK_surf) && ((n+1)%(malha.intervaloVTK_surf)==0) && rank==0 ) {
            ImprimeInterfaceVTK(malha, n+1);
            DesenhaMalhaVTK(malha, 0);
        }


        /// ==== Imprimindo arquivo de Backup usado pra debugar problemas...
        if( (malha.intervaloEstado) &&((n+1)%(malha.intervaloEstado)==0) && rank==0 )
            SalvarEstadoBinario(malha, solver.UVelho, solver.VVelho, solver.PVelho, solver.TxxVelho, solver.TxyVelho, solver.TyyVelho, solver.lambdaVelho, solver.muVelho, solver.nuVelho, listaCelulasSurf, n);

        t = t + malha.dt;
    }


    /// === Imprimindo o arquivo do ultimo passo temporal
    if( rank==0 ) {
        //ImprimeArquivoVTK(solver.UVelho, solver.VVelho, solver.WVelho, solver.PVelho, solver.TxxVelho, solver.TxyVelho, solver.TyyVelho, malha, n);
        //ImprimeArquivoVTK(solver.UVelho, solver.VVelho, solver.WVelho, solver.PVelho, solver.TxxVelho, solver.TxyVelho, solver.TyyVelho, solver.lambdaVelho, solver.muVelho, solver.nuVelho, malha, n);
        //ImprimeInterfaceVTK(malha, n);
    }


    FinalizaPrograma(&malha, &listaCelulasSurf, &solver);
    ierr = PetscFinalize();
    FinalizouNormalmente("\n\nAcabou Normalmente!\n\n");
    return 0;
}
